# The Lunar Illuminator — Wide RF Simulation

محاكاة واسعة للنطاقات والقنوات والأقمار الافتراضية.

- 100 قمر افتراضي
- نطاقات VHF/UHF/L/S/C/X/Ku/Ka
- قناة محاكاة عند 1408 MHz
- SNR وفقد المسار وجودة الإشارة ومعدل أخطاء الحزم
- RF transmission = false
- Satellite uplink = false

## التشغيل

```bash
python RF_SIMULATOR.py
```

ينتج البرنامج `RF_STATUS.json`.

**هذه حزمة محاكاة رقمية فقط ولا تنفذ بث RF أو uplink حقيقي.**
