#!/usr/bin/env python3
"""The Lunar Illuminator — safe project entry point."""
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def project_status():
    print("🌙 The Lunar Illuminator")
    print("Research • AI assistance • Safety • Privacy")
    print("Quran policy: preserve text, no fabrication, no attribution of model output.")

if __name__ == "__main__":
    project_status()
