"""Safe interface rules for Quran-related AI work."""
POLICY = {
    "preserve_text": True,
    "without_added_tafsir": True,
    "do_not_attribute_model_outputs_to_quran": True,
    "no_revelation_claims": True,
    "verify_sources": True,
    "label_uncertainty": True,
}
